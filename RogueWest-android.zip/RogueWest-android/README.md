# RogueWest для Android (версия 5.0)

Полноэкранное Android-приложение с игрой из `app/src/main/assets/index.html`.
Горизонтальная ориентация, экран не гаснет, кнопка «Назад» = пауза / шаг назад в меню,
кнопка «ВЫХОД» в главном меню закрывает приложение. Шрифты встроены — игра работает без интернета.
Сохранения (монеты, вещи, профили) хранятся внутри приложения.

## Сборка на GitHub (без компьютерных программ)
1. github.com → New repository → имя `RogueWest-android` → Create.
2. Add file → Upload files → перетащи ВСЁ содержимое папки `RogueWest-android`
   (включая скрытую папку `.github`) → Commit changes.
3. Вкладка **Actions** → Build APK → дождись зелёной галочки (3–5 минут).
4. Открой сборку → внизу **Artifacts** → скачай `RogueWest-apk` → внутри `RogueWest.apk`.

Если папка `.github` не загрузилась: Add file → Create new file,
имя `.github/workflows/build-apk.yml`, вставь текст файла из этого архива и сохрани.

## Сборка через git (терминал)
Новый репозиторий:
    cd RogueWest-android
    git init
    git add -A
    git commit -m "RogueWest 5.0"
    git branch -M main
    git remote add origin https://github.com/ТВОЙ_ЛОГИН/RogueWest-android.git
    git push -u origin main

Обновление уже существующего репозитория (после замены файлов):
    git add -A
    git commit -m "RogueWest 5.0"
    git push

После push сборка запускается сама (вкладка Actions).

## Локально (Android Studio)
File → Open → папка RogueWest-android → Build → Build APK(s).
Файл: `app/build/outputs/apk/debug/app-debug.apk`.

## Обновление игры
Замени `app/src/main/assets/index.html` и увеличь `versionCode` в `app/build.gradle` —
тогда APK встанет поверх старого без потери сохранений (подпись та же).
